-- -----------------------------
-- Think MySQL Data Transfer 
-- 
-- Host     : 127.0.0.1
-- Port     : 3306
-- Database : easycms
-- 
-- Part : #1
-- Date : 2015-12-12 06:37:14
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;


-- -----------------------------
-- Table structure for `easy_access`
-- -----------------------------
DROP TABLE IF EXISTS `easy_access`;
CREATE TABLE `easy_access` (
  `role_id` smallint(6) unsigned NOT NULL,
  `node_id` smallint(6) unsigned NOT NULL,
  `level` tinyint(1) NOT NULL,
  `module` varchar(50) DEFAULT NULL,
  KEY `groupId` (`role_id`),
  KEY `nodeId` (`node_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `easy_access`
-- -----------------------------
INSERT INTO `easy_access` VALUES ('7', '57', '3', '');
INSERT INTO `easy_access` VALUES ('7', '56', '2', '');
INSERT INTO `easy_access` VALUES ('7', '15', '3', '');
INSERT INTO `easy_access` VALUES ('7', '2', '2', '');
INSERT INTO `easy_access` VALUES ('7', '19', '3', '');
INSERT INTO `easy_access` VALUES ('7', '3', '2', '');
INSERT INTO `easy_access` VALUES ('7', '24', '3', '');
INSERT INTO `easy_access` VALUES ('7', '4', '2', '');
INSERT INTO `easy_access` VALUES ('7', '32', '3', '');
INSERT INTO `easy_access` VALUES ('7', '7', '2', '');
INSERT INTO `easy_access` VALUES ('7', '35', '3', '');
INSERT INTO `easy_access` VALUES ('7', '8', '2', '');
INSERT INTO `easy_access` VALUES ('7', '39', '3', '');
INSERT INTO `easy_access` VALUES ('7', '9', '2', '');
INSERT INTO `easy_access` VALUES ('7', '46', '3', '');
INSERT INTO `easy_access` VALUES ('7', '10', '2', '');
INSERT INTO `easy_access` VALUES ('7', '47', '3', '');
INSERT INTO `easy_access` VALUES ('7', '11', '2', '');
INSERT INTO `easy_access` VALUES ('7', '62', '2', '');
INSERT INTO `easy_access` VALUES ('7', '1', '1', '');

-- -----------------------------
-- Table structure for `easy_article`
-- -----------------------------
DROP TABLE IF EXISTS `easy_article`;
CREATE TABLE `easy_article` (
  `article_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tid` int(10) unsigned NOT NULL,
  `title` varchar(40) NOT NULL,
  `keyword` varchar(255) NOT NULL,
  `pubtime` int(10) unsigned NOT NULL,
  `summary` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `approval` int(10) unsigned NOT NULL,
  `opposition` int(10) unsigned NOT NULL,
  `iscommend` tinyint(1) unsigned NOT NULL,
  `ispush` tinyint(1) unsigned NOT NULL,
  `isslides` tinyint(1) unsigned NOT NULL,
  `islock` tinyint(1) unsigned NOT NULL,
  PRIMARY KEY (`article_id`)
) ENGINE=MyISAM AUTO_INCREMENT=43 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `easy_article`
-- -----------------------------
INSERT INTO `easy_article` VALUES ('36', '74', '日本人最期望谁当下届首相', '日本,首相', '1449552781', '《每日新闻》是日本6大主流报系中反安倍色彩较浓的报纸，它在5-6日实施了一次全国舆论调查，结果发现，安倍内阁的支持率已经超过不支持率，达到了43%，实现了今年7月以来的大逆转，显示安倍政权即使在反安倍的阵营中，也获得了很高的人气。', '<span style=\"font-family:SimSun;font-size: 14px;\">《每日新闻》是日本6大主流报系中反安倍色彩较浓的报纸，它在5-6日实施了一次全国舆论调查，结果发现，安倍内阁的支持率已经超过不支持率，达到了43%，实现了今年7月以来的大逆转，显示安倍政权即使在反安倍的阵营中，也获得了很高的人气。</span><p style=\"margin: 0px; line-height: normal; -webkit-text-stroke-color: rgb(0, 0, 0); -webkit-text-stroke-width: initial;\"><span style=\"font-family:SimSun;font-size: 14px;\">　　安倍当首相还能当到什么时候？谁也无法预计。理论上，他作为自民党总裁，在今年9月刚刚获得连任后，至少可以保证自己把首相当到2018年。但是，安倍首相本人也许更期望能够在2020年的<a href=\"http://blog.sina.com.cn/lm/z/sakura/\" class=\"yinghua_a\" target=\"_blank\">东京</a>奥运会开幕式上，能够以首相的身份主持。这样一算的话，安倍至少还想当5年。当然，自己想当，和政局是否允许他当，那是完全的两码事。也就是说，安倍首相在2016年突然辞职的可能性也不能否定。</span></p><p style=\"margin: 0px; line-height: normal; -webkit-text-stroke-color: rgb(0, 0, 0); -webkit-text-stroke-width: initial;\"><span style=\"font-family:SimSun;font-size: 14px;\"><br /></span></p><p style=\"margin: 0px; line-height: normal; -webkit-text-stroke-color: rgb(0, 0, 0); -webkit-text-stroke-width: initial;\"><a href=\"http://photo.blog.sina.com.cn/showpic.html#blogid=4cd1c1670102vyok&amp;url=http://album.sina.com.cn/pic/001pdJDVgy6XAWgjReof8\" target=\"_blank\"><img src=\"http://s9.sinaimg.cn/mw690/001pdJDVgy6XAWgjReof8&amp;690\" style=\"margin: 0pt auto;display:block\" name=\"image_operate_75721449503427964\" alt=\"日本人最期望谁当下届首相？\" title=\"日本人最期望谁当下届首相？\" height=\"502\" width=\"690\" /></a><br /><br /></p><p style=\"margin: 0px; line-height: normal; -webkit-text-stroke-color: rgb(0, 0, 0); -webkit-text-stroke-width: initial;\"><span style=\"font-family:SimSun;font-size: 14px;\">　　虽然安倍首相的支持率在出现回升，但是日本的一些八卦媒体也不断爆出“安倍病危”的消息，似乎是期望他早早下台，甚至希望他得什么恶病。不过，即使平时繁忙的工作都以分钟算，安倍首相看上去还是比较健康，距离下台似乎还有很长一段路要走。</span></p><p style=\"margin: 0px; line-height: normal; -webkit-text-stroke-color: rgb(0, 0, 0); -webkit-text-stroke-width: initial;\"><span style=\"font-family:SimSun;font-size: 14px;\">　　不管安倍首相是不是期望自己如何长期执政，日本的媒体已经开始为他“安排后事”。日本另一家著名的报纸《朝日新闻》，最近对自民党所属的500多名国会议员进行了一次问卷调查：你认为谁最适合当下一届的首相？结果显示，期望安倍继续当首相的比例仅为7%，而排在他前面的，是他的政治对手石破茂，比例高达18%，名列第一。</span></p><p style=\"margin: 0px; line-height: normal; -webkit-text-stroke-color: rgb(0, 0, 0); -webkit-text-stroke-width: initial;\"><span style=\"font-family:SimSun;font-size: 14px;\"><br /></span></p><p style=\"margin: 0px; line-height: normal; -webkit-text-stroke-color: rgb(0, 0, 0); -webkit-text-stroke-width: initial;\"><a href=\"http://photo.blog.sina.com.cn/showpic.html#blogid=4cd1c1670102vyok&amp;url=http://album.sina.com.cn/pic/001pdJDVgy6XAWzSL11bb\" target=\"_blank\"><img src=\"http://s12.sinaimg.cn/mw690/001pdJDVgy6XAWzSL11bb&amp;690\" style=\"margin: 0pt auto;display:block\" name=\"image_operate_28831449503428503\" alt=\"日本人最期望谁当下届首相？\" title=\"日本人最期望谁当下届首相？\" height=\"1125\" width=\"690\" /></a><br /><br /></p><p style=\"margin: 0px; line-height: normal; -webkit-text-stroke-color: rgb(0, 0, 0); -webkit-text-stroke-width: initial;\"><span style=\"font-family:SimSun;font-size: 14px;\">　　日本人为何希望石破茂来接替安倍当首相呢？首先是石破茂的性格稳定性让大家有一种安定感。石破茂虽然担任过两届的防卫大臣，属于鹰派的政治家，但是无论是在日美安保，还是日中关系，他都坚持不偏不倚的立场与观点，尤其是他说话的语气一直是稳稳当当，因此让许多人认为，石破茂当首相，不会像安倍那样冒进和激昂。其二，石破茂由于其说话中肯，观点新颖，因此一直是日本各大电视台的第一嘉宾，虽然眼睛有些斜视，但是仍然获得许多观众的喜爱，知名度很高。其三，石破茂担任过执政的自民党干事长，并协助安倍首相取得了众议院和参议院大选的胜利，是安倍政权建立的功劳者。也就是说，安倍首相有今天，离不开石破茂的努力。但是，安倍首相在解除他的干事长职务后，给了他一个难有建树且吃力不讨好的职位－－地方创生大臣，被舆论认为是安倍首相刻意架空石破茂政治影响力的一种做法，因此许多人对他颇有同情之感。</span></p><p style=\"margin: 0px; line-height: normal; -webkit-text-stroke-color: rgb(0, 0, 0); -webkit-text-stroke-width: initial;\"><span style=\"font-family:SimSun;font-size: 14px;\"><br /></span></p><p style=\"margin: 0px; line-height: normal; -webkit-text-stroke-color: rgb(0, 0, 0); -webkit-text-stroke-width: initial;\"><a href=\"http://photo.blog.sina.com.cn/showpic.html#blogid=4cd1c1670102vyok&amp;url=http://album.sina.com.cn/pic/001pdJDVgy6XAWioimD63\" target=\"_blank\"><img src=\"http://s4.sinaimg.cn/mw690/001pdJDVgy6XAWioimD63&amp;690\" style=\"margin: 0pt auto;display:block\" name=\"image_operate_98391449503429869\" alt=\"日本人最期望谁当下届首相？\" title=\"日本人最期望谁当下届首相？\" height=\"920\" width=\"690\" /></a></p><div style=\"text-align: center;\"><span style=\"line-height: normal; -webkit-text-stroke-width: initial;\">野心勃勃的石破茂</span></div><br /><br /><p style=\"margin: 0px; line-height: normal; -webkit-text-stroke-color: rgb(0, 0, 0); -webkit-text-stroke-width: initial;\"><span style=\"font-family:SimSun;font-size: 14px;\">　　石破茂在今年9月已经组建了自己的党内派阀，明确表示将要接安倍的班。即使如此，民众也没有对他赤裸裸的野心表示反感，反而觉得他做人光明磊落。</span></p><p style=\"margin: 0px; line-height: normal; -webkit-text-stroke-color: rgb(0, 0, 0); -webkit-text-stroke-width: initial;\"><span style=\"font-family:SimSun;font-size: 14px;\">　　除石破茂之外，另一位与安倍首相并列第二位的政治家，是一位年近33岁的少壮派人物，名叫“小泉进次郎”。小泉进次郎是日本前首相小泉纯一郎的儿子，他接替父亲的选区当选众议员议员后，一直以敢说敢言，独行独立的“小泉家风”从事政治活动，在日本国民中人气十足，被称为是“自民党王子”。</span></p><p style=\"margin: 0px; line-height: normal; -webkit-text-stroke-color: rgb(0, 0, 0); -webkit-text-stroke-width: initial;\"><span style=\"font-family:SimSun;font-size: 14px;\">　　小泉进次郎担任过自民党青年局长，此后担任过安倍第二次内阁的复兴副大臣。在今年9月的安倍内阁改造中，安倍首相原计划起用小泉进次郎首进内阁担任大臣，但是没有想到，小泉认为自己还太年轻，还不具备当大臣的资格，因此拒绝了安倍首相的邀请。小泉进次郎的这一决定，让日本民众对他刮目相看－－这个人心很大，不会计较个人荣誉得失。</span></p><p style=\"margin: 0px; line-height: normal; -webkit-text-stroke-color: rgb(0, 0, 0); -webkit-text-stroke-width: initial;\"><span style=\"font-family:SimSun;font-size: 14px;\">　　在小泉进次郎拒绝出任大臣之后，安倍首相任命他出任自民党的农林水产部会部会长。这一职务看起来很小，但是是自民党历代首相大多担任过的一个“出道”职位。而对于安倍政权来说，因为面临日本加盟TPP引发的农副产品关税问题在国会的辩论与决断，因此这一个职位是自民党目前最为重要的职务之一，部会长担负着与中央各相关机关的协调和平息党内不满势力的重任，是一个很锻炼人的岗位。安倍首相的这一安倍，也被认为是他刻意培养自己政治兄长的儿子将来接任首相位子的一个重要举措。</span></p><p style=\"margin: 0px; line-height: normal; -webkit-text-stroke-color: rgb(0, 0, 0); -webkit-text-stroke-width: initial;\"><span style=\"font-family:SimSun;font-size: 14px;\"><br /></span></p><p style=\"margin: 0px; line-height: normal; -webkit-text-stroke-color: rgb(0, 0, 0); -webkit-text-stroke-width: initial;\"><a href=\"http://photo.blog.sina.com.cn/showpic.html#blogid=4cd1c1670102vyok&amp;url=http://album.sina.com.cn/pic/001pdJDVgy6XAWpc8Tnf9\" target=\"_blank\"><img src=\"http://s10.sinaimg.cn/mw690/001pdJDVgy6XAWpc8Tnf9&amp;690\" style=\"margin: 0pt auto;display:block\" name=\"image_operate_78021449503430706\" alt=\"日本人最期望谁当下届首相？\" title=\"日本人最期望谁当下届首相？\" height=\"460\" width=\"690\" /></a></p><div style=\"text-align: center;\"><span style=\"line-height: normal; -webkit-text-stroke-width: initial;\">青年俊才小泉进次郎</span></div><br /><p style=\"margin: 0px; line-height: normal; -webkit-text-stroke-color: rgb(0, 0, 0); -webkit-text-stroke-width: initial;\"><span style=\"font-family:SimSun;font-size: 14px;\">　　自然，小泉进次郎由于太年轻，不可能成为安倍首相的接班人。但是，石破茂成为“安倍后”的第一首相候选人，应该是不争的事实。不过，石破茂也不能太过于乐观，如果他领导的政治势力与安倍领导的政治势力出现对立的话，一定有人会渔翁得利，这个人就是现任自民党干事长的谷垣祯一。</span></p><p style=\"margin: 0px; line-height: normal; -webkit-text-stroke-color: rgb(0, 0, 0); -webkit-text-stroke-width: initial;\"><span style=\"font-family:SimSun;font-size: 14px;\">　　这位性格沉稳，人生悲情的政治家，在自民党于2009年下野时，无人收拾自民党残局，他临危受命，出任自民党总裁。而在自民党重新夺取政权时，夫人病故，因此好事都没有轮到过他，颇受党内各派人士同情。即使当过党总裁，又屈任党干事长，谷垣祯一毫无怨言，而且对安倍对石破茂都是一碗水端平，被认为是党内最佳的“和事佬”。前几天，他还带领日本执政党代表团访问北京。</span></p><p style=\"margin: 0px; line-height: normal; -webkit-text-stroke-color: rgb(0, 0, 0); -webkit-text-stroke-width: initial;\"><span style=\"font-family:SimSun;font-size: 14px;\"><br /></span></p><p style=\"margin: 0px; line-height: normal; -webkit-text-stroke-color: rgb(0, 0, 0); -webkit-text-stroke-width: initial;\"><a href=\"http://photo.blog.sina.com.cn/showpic.html#blogid=4cd1c1670102vyok&amp;url=http://album.sina.com.cn/pic/001pdJDVgy6XAWslnyo08\" target=\"_blank\"><img src=\"http://s9.sinaimg.cn/mw690/001pdJDVgy6XAWslnyo08&amp;690\" style=\"margin: 0pt auto;display:block\" name=\"image_operate_82531449503431607\" alt=\"日本人最期望谁当下届首相？\" title=\"日本人最期望谁当下届首相？\" height=\"907\" width=\"690\" /></a></p><div style=\"text-align: center;\"><span style=\"line-height: normal; -webkit-text-stroke-width: initial;\">好男人石垣祯一</span></div><br /><p style=\"margin: 0px; line-height: normal; -webkit-text-stroke-color: rgb(0, 0, 0); -webkit-text-stroke-width: initial;\"><span style=\"font-family:SimSun;font-size: 14px;\">　　许多的推测只有在安倍下台后才能得到验证，但是民意和议员的政治恳望，也能让我们看到安倍之后将会有谁来掌控日本这一邻国。候选人就这么几个，我们不妨可以先做些和谐外交工作，提前沟通，预热友谊，也许会更有利于中日两国关系的改善与发展。</span></p><p style=\"margin: 0px; line-height: normal; -webkit-text-stroke-color: rgb(0, 0, 0); -webkit-text-stroke-width: initial;\"><span style=\"font-family:SimSun;font-size: 14px;\"><br /></span></p><p style=\"margin: 0px; line-height: normal; -webkit-text-stroke-color: rgb(0, 0, 0); -webkit-text-stroke-width: initial;\"><span style=\"font-family:\'Hiragino Kaku Gothic pro\';font-size:16px;color:#323333;line-height: 23.11111068725586px; -webkit-text-stroke-color: rgb(50, 51, 51); background-color: rgb(255, 255, 255);\">&nbsp;<wbr> &nbsp;<wbr></wbr></wbr></span> <span style=\"font-family:\'Hiragino Kaku Gothic pro\';color:#323333;line-height: 23.11111068725586px; -webkit-text-stroke-color: rgb(50, 51, 51); background-color: rgb(255, 255, 255);\"><span style=\"font-size: 14px;\">&nbsp;<wbr>【荐读徐静波立体解读当今日本社会与日本人的最新著作《静观日本》，华文出版社出版，网上有售】</wbr></span></span></p><p style=\"margin: 0px; line-height: normal; -webkit-text-stroke-color: rgb(0, 0, 0); -webkit-text-stroke-width: initial;\"><span style=\"font-family:\'Hiragino Kaku Gothic pro\';color:#323333;line-height: 23.11111068725586px; -webkit-text-stroke-color: rgb(50, 51, 51); background-color: rgb(255, 255, 255);\"><span style=\"font-size: 14px;\"><br /></span></span></p><p style=\"margin: 0px; line-height: normal; -webkit-text-stroke-color: rgb(0, 0, 0); -webkit-text-stroke-width: initial;\"><a href=\"http://photo.blog.sina.com.cn/showpic.html#blogid=4cd1c1670102vyok&amp;url=http://album.sina.com.cn/pic/001pdJDVgy6XBp5xxrd03\" target=\"_blank\"><img src=\"http://s4.sinaimg.cn/mw690/001pdJDVgy6XBp5xxrd03&amp;690\" style=\"margin: 0pt auto;display:block\" name=\"image_operate_34051449528240027\" alt=\"日本人最期望谁当下届首相？\" title=\"日本人最期望谁当下届首相？\" height=\"920\" width=\"690\" /></a></p>					', '0', '0', '1', '1', '0', '0');
INSERT INTO `easy_article` VALUES ('37', '76', '马鑫VS江良元', '是的', '1449712008', '《每日新闻》是日本6大主流报系中反安倍色彩较浓的报纸，它在5-6日实施了一次全国舆论调查，结果发现，安倍内阁的支持率已经超过不支持率，达到了43%，实现了今年7月以来的大逆转，显示安倍政权即使在反安倍的阵营中，也获得了很高的人气。', '<span style=\"font-family:SimSun;font-size: 14px;\">《每日新闻》是日本6大主流报系中反安倍色彩较浓的报纸，它在5-6日实施了一次全国舆论调查，结果发现，安倍内阁的支持率已经超过不支持率，达到了43%，实现了今年7月以来的大逆转，显示安倍政权即使在反安倍的阵营中，也获得了很高的人气。</span><p style=\"margin: 0px; line-height: normal; -webkit-text-stroke-color: rgb(0, 0, 0); -webkit-text-stroke-width: initial;\"><span style=\"font-family:SimSun;font-size: 14px;\">　　安倍当首相还能当到什么时候？谁也无法预计。理论上，他作为自民党总裁，在今年9月刚刚获得连任后，至少可以保证自己把首相当到2018年。但是，安倍首相本人也许更期望能够在2020年的<a href=\"http://blog.sina.com.cn/lm/z/sakura/\" class=\"yinghua_a\" target=\"_blank\">东京</a>奥运会开幕式上，能够以首相的身份主持。这样一算的话，安倍至少还想当5年。当然，自己想当，和政局是否允许他当，那是完全的两码事。也就是说，安倍首相在2016年突然辞职的可能性也不能否定。</span></p><p style=\"margin: 0px; line-height: normal; -webkit-text-stroke-color: rgb(0, 0, 0); -webkit-text-stroke-width: initial;\"><span style=\"font-family:SimSun;font-size: 14px;\"><br /></span></p><p style=\"margin: 0px; line-height: normal; -webkit-text-stroke-color: rgb(0, 0, 0); -webkit-text-stroke-width: initial;\"><a href=\"http://photo.blog.sina.com.cn/showpic.html#blogid=4cd1c1670102vyok&amp;url=http://album.sina.com.cn/pic/001pdJDVgy6XAWgjReof8\" target=\"_blank\"><img src=\"http://s9.sinaimg.cn/mw690/001pdJDVgy6XAWgjReof8&amp;690\" style=\"margin: 0pt auto;display:block\" name=\"image_operate_75721449503427964\" alt=\"日本人最期望谁当下届首相？\" title=\"日本人最期望谁当下届首相？\" height=\"502\" width=\"690\" /></a><br /><br /></p><p style=\"margin: 0px; line-height: normal; -webkit-text-stroke-color: rgb(0, 0, 0); -webkit-text-stroke-width: initial;\"><span style=\"font-family:SimSun;font-size: 14px;\">　　虽然安倍首相的支持率在出现回升，但是日本的一些八卦媒体也不断爆出“安倍病危”的消息，似乎是期望他早早下台，甚至希望他得什么恶病。不过，即使平时繁忙的工作都以分钟算，安倍首相看上去还是比较健康，距离下台似乎还有很长一段路要走。</span></p><p style=\"margin: 0px; line-height: normal; -webkit-text-stroke-color: rgb(0, 0, 0); -webkit-text-stroke-width: initial;\"><span style=\"font-family:SimSun;font-size: 14px;\">　　不管安倍首相是不是期望自己如何长期执政，日本的媒体已经开始为他“安排后事”。日本另一家著名的报纸《朝日新闻》，最近对自民党所属的500多名国会议员进行了一次问卷调查：你认为谁最适合当下一届的首相？结果显示，期望安倍继续当首相的比例仅为7%，而排在他前面的，是他的政治对手石破茂，比例高达18%，名列第一。</span></p><p style=\"margin: 0px; line-height: normal; -webkit-text-stroke-color: rgb(0, 0, 0); -webkit-text-stroke-width: initial;\"><span style=\"font-family:SimSun;font-size: 14px;\"><br /></span></p><p style=\"margin: 0px; line-height: normal; -webkit-text-stroke-color: rgb(0, 0, 0); -webkit-text-stroke-width: initial;\"><a href=\"http://photo.blog.sina.com.cn/showpic.html#blogid=4cd1c1670102vyok&amp;url=http://album.sina.com.cn/pic/001pdJDVgy6XAWzSL11bb\" target=\"_blank\"><img src=\"http://s12.sinaimg.cn/mw690/001pdJDVgy6XAWzSL11bb&amp;690\" style=\"margin: 0pt auto;display:block\" name=\"image_operate_28831449503428503\" alt=\"日本人最期望谁当下届首相？\" title=\"日本人最期望谁当下届首相？\" height=\"1125\" width=\"690\" /></a><br /><br /></p><p style=\"margin: 0px; line-height: normal; -webkit-text-stroke-color: rgb(0, 0, 0); -webkit-text-stroke-width: initial;\"><span style=\"font-family:SimSun;font-size: 14px;\">　　日本人为何希望石破茂来接替安倍当首相呢？首先是石破茂的性格稳定性让大家有一种安定感。石破茂虽然担任过两届的防卫大臣，属于鹰派的政治家，但是无论是在日美安保，还是日中关系，他都坚持不偏不倚的立场与观点，尤其是他说话的语气一直是稳稳当当，因此让许多人认为，石破茂当首相，不会像安倍那样冒进和激昂。其二，石破茂由于其说话中肯，观点新颖，因此一直是日本各大电视台的第一嘉宾，虽然眼睛有些斜视，但是仍然获得许多观众的喜爱，知名度很高。其三，石破茂担任过执政的自民党干事长，并协助安倍首相取得了众议院和参议院大选的胜利，是安倍政权建立的功劳者。也就是说，安倍首相有今天，离不开石破茂的努力。但是，安倍首相在解除他的干事长职务后，给了他一个难有建树且吃力不讨好的职位－－地方创生大臣，被舆论认为是安倍首相刻意架空石破茂政治影响力的一种做法，因此许多人对他颇有同情之感。</span></p><p style=\"margin: 0px; line-height: normal; -webkit-text-stroke-color: rgb(0, 0, 0); -webkit-text-stroke-width: initial;\"><span style=\"font-family:SimSun;font-size: 14px;\"><br /></span></p><p style=\"margin: 0px; line-height: normal; -webkit-text-stroke-color: rgb(0, 0, 0); -webkit-text-stroke-width: initial;\"><a href=\"http://photo.blog.sina.com.cn/showpic.html#blogid=4cd1c1670102vyok&amp;url=http://album.sina.com.cn/pic/001pdJDVgy6XAWioimD63\" target=\"_blank\"><img src=\"http://s4.sinaimg.cn/mw690/001pdJDVgy6XAWioimD63&amp;690\" style=\"margin: 0pt auto;display:block\" name=\"image_operate_98391449503429869\" alt=\"日本人最期望谁当下届首相？\" title=\"日本人最期望谁当下届首相？\" height=\"920\" width=\"690\" /></a></p><div style=\"text-align: center;\"><span style=\"line-height: normal; -webkit-text-stroke-width: initial;\">野心勃勃的石破茂</span></div><br /><br /><p style=\"margin: 0px; line-height: normal; -webkit-text-stroke-color: rgb(0, 0, 0); -webkit-text-stroke-width: initial;\"><span style=\"font-family:SimSun;font-size: 14px;\">　　石破茂在今年9月已经组建了自己的党内派阀，明确表示将要接安倍的班。即使如此，民众也没有对他赤裸裸的野心表示反感，反而觉得他做人光明磊落。</span></p><p style=\"margin: 0px; line-height: normal; -webkit-text-stroke-color: rgb(0, 0, 0); -webkit-text-stroke-width: initial;\"><span style=\"font-family:SimSun;font-size: 14px;\">　　除石破茂之外，另一位与安倍首相并列第二位的政治家，是一位年近33岁的少壮派人物，名叫“小泉进次郎”。小泉进次郎是日本前首相小泉纯一郎的儿子，他接替父亲的选区当选众议员议员后，一直以敢说敢言，独行独立的“小泉家风”从事政治活动，在日本国民中人气十足，被称为是“自民党王子”。</span></p><p style=\"margin: 0px; line-height: normal; -webkit-text-stroke-color: rgb(0, 0, 0); -webkit-text-stroke-width: initial;\"><span style=\"font-family:SimSun;font-size: 14px;\">　　小泉进次郎担任过自民党青年局长，此后担任过安倍第二次内阁的复兴副大臣。在今年9月的安倍内阁改造中，安倍首相原计划起用小泉进次郎首进内阁担任大臣，但是没有想到，小泉认为自己还太年轻，还不具备当大臣的资格，因此拒绝了安倍首相的邀请。小泉进次郎的这一决定，让日本民众对他刮目相看－－这个人心很大，不会计较个人荣誉得失。</span></p><p style=\"margin: 0px; line-height: normal; -webkit-text-stroke-color: rgb(0, 0, 0); -webkit-text-stroke-width: initial;\"><span style=\"font-family:SimSun;font-size: 14px;\">　　在小泉进次郎拒绝出任大臣之后，安倍首相任命他出任自民党的农林水产部会部会长。这一职务看起来很小，但是是自民党历代首相大多担任过的一个“出道”职位。而对于安倍政权来说，因为面临日本加盟TPP引发的农副产品关税问题在国会的辩论与决断，因此这一个职位是自民党目前最为重要的职务之一，部会长担负着与中央各相关机关的协调和平息党内不满势力的重任，是一个很锻炼人的岗位。安倍首相的这一安倍，也被认为是他刻意培养自己政治兄长的儿子将来接任首相位子的一个重要举措。</span></p><p style=\"margin: 0px; line-height: normal; -webkit-text-stroke-color: rgb(0, 0, 0); -webkit-text-stroke-width: initial;\"><span style=\"font-family:SimSun;font-size: 14px;\"><br /></span></p><p style=\"margin: 0px; line-height: normal; -webkit-text-stroke-color: rgb(0, 0, 0); -webkit-text-stroke-width: initial;\"><a href=\"http://photo.blog.sina.com.cn/showpic.html#blogid=4cd1c1670102vyok&amp;url=http://album.sina.com.cn/pic/001pdJDVgy6XAWpc8Tnf9\" target=\"_blank\"><img src=\"http://s10.sinaimg.cn/mw690/001pdJDVgy6XAWpc8Tnf9&amp;690\" style=\"margin: 0pt auto;display:block\" name=\"image_operate_78021449503430706\" alt=\"日本人最期望谁当下届首相？\" title=\"日本人最期望谁当下届首相？\" height=\"460\" width=\"690\" /></a></p><div style=\"text-align: center;\"><span style=\"line-height: normal; -webkit-text-stroke-width: initial;\">青年俊才小泉进次郎</span></div><br /><p style=\"margin: 0px; line-height: normal; -webkit-text-stroke-color: rgb(0, 0, 0); -webkit-text-stroke-width: initial;\"><span style=\"font-family:SimSun;font-size: 14px;\">　　自然，小泉进次郎由于太年轻，不可能成为安倍首相的接班人。但是，石破茂成为“安倍后”的第一首相候选人，应该是不争的事实。不过，石破茂也不能太过于乐观，如果他领导的政治势力与安倍领导的政治势力出现对立的话，一定有人会渔翁得利，这个人就是现任自民党干事长的谷垣祯一。</span></p><p style=\"margin: 0px; line-height: normal; -webkit-text-stroke-color: rgb(0, 0, 0); -webkit-text-stroke-width: initial;\"><span style=\"font-family:SimSun;font-size: 14px;\">　　这位性格沉稳，人生悲情的政治家，在自民党于2009年下野时，无人收拾自民党残局，他临危受命，出任自民党总裁。而在自民党重新夺取政权时，夫人病故，因此好事都没有轮到过他，颇受党内各派人士同情。即使当过党总裁，又屈任党干事长，谷垣祯一毫无怨言，而且对安倍对石破茂都是一碗水端平，被认为是党内最佳的“和事佬”。前几天，他还带领日本执政党代表团访问北京。</span></p><p style=\"margin: 0px; line-height: normal; -webkit-text-stroke-color: rgb(0, 0, 0); -webkit-text-stroke-width: initial;\"><span style=\"font-family:SimSun;font-size: 14px;\"><br /></span></p><p style=\"margin: 0px; line-height: normal; -webkit-text-stroke-color: rgb(0, 0, 0); -webkit-text-stroke-width: initial;\"><a href=\"http://photo.blog.sina.com.cn/showpic.html#blogid=4cd1c1670102vyok&amp;url=http://album.sina.com.cn/pic/001pdJDVgy6XAWslnyo08\" target=\"_blank\"><img src=\"http://s9.sinaimg.cn/mw690/001pdJDVgy6XAWslnyo08&amp;690\" style=\"margin: 0pt auto;display:block\" name=\"image_operate_82531449503431607\" alt=\"日本人最期望谁当下届首相？\" title=\"日本人最期望谁当下届首相？\" height=\"907\" width=\"690\" /></a></p><div style=\"text-align: center;\"><span style=\"line-height: normal; -webkit-text-stroke-width: initial;\">好男人石垣祯一</span></div><br /><p style=\"margin: 0px; line-height: normal; -webkit-text-stroke-color: rgb(0, 0, 0); -webkit-text-stroke-width: initial;\"><span style=\"font-family:SimSun;font-size: 14px;\">　　许多的推测只有在安倍下台后才能得到验证，但是民意和议员的政治恳望，也能让我们看到安倍之后将会有谁来掌控日本这一邻国。候选人就这么几个，我们不妨可以先做些和谐外交工作，提前沟通，预热友谊，也许会更有利于中日两国关系的改善与发展。</span></p><p style=\"margin: 0px; line-height: normal; -webkit-text-stroke-color: rgb(0, 0, 0); -webkit-text-stroke-width: initial;\"><span style=\"font-family:SimSun;font-size: 14px;\"><br /></span></p><p style=\"margin: 0px; line-height: normal; -webkit-text-stroke-color: rgb(0, 0, 0); -webkit-text-stroke-width: initial;\"><span style=\"font-family:\'Hiragino Kaku Gothic pro\';font-size:16px;color:#323333;line-height: 23.11111068725586px; -webkit-text-stroke-color: rgb(50, 51, 51); background-color: rgb(255, 255, 255);\">&nbsp;<wbr> &nbsp;<wbr></wbr></wbr></span> <span style=\"font-family:\'Hiragino Kaku Gothic pro\';color:#323333;line-height: 23.11111068725586px; -webkit-text-stroke-color: rgb(50, 51, 51); background-color: rgb(255, 255, 255);\"><span style=\"font-size: 14px;\">&nbsp;<wbr>【荐读徐静波立体解读当今日本社会与日本人的最新著作《静观日本》，华文出版社出版，网上有售】</wbr></span></span></p><p style=\"margin: 0px; line-height: normal; -webkit-text-stroke-color: rgb(0, 0, 0); -webkit-text-stroke-width: initial;\"><span style=\"font-family:\'Hiragino Kaku Gothic pro\';color:#323333;line-height: 23.11111068725586px; -webkit-text-stroke-color: rgb(50, 51, 51); background-color: rgb(255, 255, 255);\"><span style=\"font-size: 14px;\"><br /></span></span></p><p style=\"margin: 0px; line-height: normal; -webkit-text-stroke-color: rgb(0, 0, 0); -webkit-text-stroke-width: initial;\"><a href=\"http://photo.blog.sina.com.cn/showpic.html#blogid=4cd1c1670102vyok&amp;url=http://album.sina.com.cn/pic/001pdJDVgy6XBp5xxrd03\" target=\"_blank\"><img src=\"http://s4.sinaimg.cn/mw690/001pdJDVgy6XBp5xxrd03&amp;690\" style=\"margin: 0pt auto;display:block\" name=\"image_operate_34051449528240027\" alt=\"日本人最期望谁当下届首相？\" title=\"日本人最期望谁当下届首相？\" height=\"920\" width=\"690\" /></a></p>										', '0', '0', '1', '0', '0', '0');
INSERT INTO `easy_article` VALUES ('38', '77', '你知道我知道你不知道', '知道', '1449723944', '你知道我知道你不知道', '你知道我知道你不知道你知道我知道你不知道你知道我知道你不知道你知道我知道你不知道你知道我知道你不知道你知道我知道你不知道你知道我知道你不知道你知道我知道你不知道你知道我知道你不知道你知道我知道你不知道你知道我知道你不知道你知道我知道你不知道你知道我知道你不知道你知道我知道你不知道你知道我知道你不知道你知道我知道你不知道你知道我知道你不知道你知道我知道你不知道你知道我知道你不知道你知道我知道你不知道你知道我知道你不知道你知道我知道你不知道你知道我知道你不知道你知道我知道你不知道你知道我知道你不知道你知道我知道你不知道你知道我知道你不知道你知道我知道你不知道你知道我知道你不知道你知道我知道你不知道你知道我知道你不知道你知道我知道你不知道你知道我知道你不知道你知道我知道你不知道你知道我知道你不知道你知道我知道你不知道你知道我知道你不知道你知道我知道你不知道你知道我知道你不知道你知道我知道你不知道你知道我知道你不知道你知道我知道你不知道你知道我知道你不知道你知道我知道你不知道你知道我知道你不知道					', '0', '0', '1', '1', '0', '0');
INSERT INTO `easy_article` VALUES ('39', '85', '阿斯顿发斯蒂芬', '啊发生地方', '1449865532', '阿斯顿法师打发斯蒂芬按时', '撒的发生大法师打发斯蒂芬					', '0', '0', '1', '0', '0', '0');
INSERT INTO `easy_article` VALUES ('40', '87', '1111111', '22222222222', '1449867508', '333333333', '4444444444					', '0', '0', '1', '0', '0', '0');
INSERT INTO `easy_article` VALUES ('41', '76', '13213', '123123123', '1449872292', '123123123', '123123123123					', '0', '0', '1', '0', '0', '0');
INSERT INTO `easy_article` VALUES ('42', '76', '3123', '123123123', '1449872310', '12312312312', '123123123123					', '0', '0', '1', '0', '0', '0');

-- -----------------------------
-- Table structure for `easy_category`
-- -----------------------------
DROP TABLE IF EXISTS `easy_category`;
CREATE TABLE `easy_category` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` char(15) NOT NULL DEFAULT '',
  `pid` int(10) unsigned NOT NULL DEFAULT '0',
  `sort` int(6) NOT NULL DEFAULT '100',
  `modelid` tinyint(1) NOT NULL DEFAULT '0',
  `isshow` tinyint(1) NOT NULL DEFAULT '1',
  `isverify` tinyint(1) NOT NULL DEFAULT '1',
  `ispush` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `pid` (`pid`)
) ENGINE=MyISAM AUTO_INCREMENT=92 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `easy_category`
-- -----------------------------
INSERT INTO `easy_category` VALUES ('71', '南开好项目', '0', '20', '0', '1', '1', '1');
INSERT INTO `easy_category` VALUES ('72', '私董会', '0', '30', '0', '1', '1', '1');
INSERT INTO `easy_category` VALUES ('73', '投资机构', '0', '40', '0', '1', '1', '1');
INSERT INTO `easy_category` VALUES ('74', '创投学院', '0', '50', '0', '1', '1', '1');
INSERT INTO `easy_category` VALUES ('75', '赛区', '0', '60', '0', '1', '1', '1');
INSERT INTO `easy_category` VALUES ('76', '创投学院', '74', '10', '0', '0', '1', '0');
INSERT INTO `easy_category` VALUES ('77', '媒体资讯', '74', '20', '0', '0', '1', '0');
INSERT INTO `easy_category` VALUES ('78', '深圳', '75', '10', '0', '0', '1', '0');
INSERT INTO `easy_category` VALUES ('79', '天津', '75', '20', '0', '0', '1', '0');
INSERT INTO `easy_category` VALUES ('80', '上海', '75', '30', '0', '0', '1', '0');
INSERT INTO `easy_category` VALUES ('81', '郑州', '75', '40', '0', '0', '1', '0');
INSERT INTO `easy_category` VALUES ('82', '大连', '75', '50', '0', '0', '1', '0');
INSERT INTO `easy_category` VALUES ('83', '成都', '75', '60', '0', '0', '1', '0');
INSERT INTO `easy_category` VALUES ('84', '昆明', '75', '70', '0', '0', '1', '0');
INSERT INTO `easy_category` VALUES ('85', '媒体机构', '73', '20', '0', '0', '1', '0');
INSERT INTO `easy_category` VALUES ('86', '关于我们', '0', '70', '0', '1', '1', '0');
INSERT INTO `easy_category` VALUES ('87', '投资机构', '73', '10', '0', '0', '1', '0');
INSERT INTO `easy_category` VALUES ('88', '关于我们', '86', '10', '0', '0', '1', '0');
INSERT INTO `easy_category` VALUES ('89', '联系我们', '86', '20', '0', '0', '1', '0');
INSERT INTO `easy_category` VALUES ('90', '加入我们', '86', '30', '0', '0', '1', '0');
INSERT INTO `easy_category` VALUES ('91', '服务与支持', '86', '40', '0', '0', '1', '0');

-- -----------------------------
-- Table structure for `easy_comment`
-- -----------------------------
DROP TABLE IF EXISTS `easy_comment`;
CREATE TABLE `easy_comment` (
  `commend_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(10) unsigned NOT NULL,
  `aid` int(10) unsigned NOT NULL,
  `content` text NOT NULL,
  `islock` tinyint(1) unsigned NOT NULL,
  `pubtime` int(11) NOT NULL,
  PRIMARY KEY (`commend_id`)
) ENGINE=MyISAM AUTO_INCREMENT=32 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `easy_comment`
-- -----------------------------
INSERT INTO `easy_comment` VALUES ('1', '1', '12', '很受用，学习了哦', '0', '1395025593');
INSERT INTO `easy_comment` VALUES ('2', '1', '12', '以后一定要避免呀', '0', '1395025898');
INSERT INTO `easy_comment` VALUES ('3', '1', '12', '测试一下态度方法', '0', '1395025947');
INSERT INTO `easy_comment` VALUES ('4', '1', '12', '继续进行态度测试', '0', '1395025991');
INSERT INTO `easy_comment` VALUES ('5', '1', '12', '继续测试吧', '0', '1395026059');
INSERT INTO `easy_comment` VALUES ('6', '1', '12', '测试加1', '0', '1395026108');
INSERT INTO `easy_comment` VALUES ('7', '1', '12', '支持一下', '0', '1395026145');
INSERT INTO `easy_comment` VALUES ('8', '1', '12', '不喜欢，反对', '0', '1395026174');
INSERT INTO `easy_comment` VALUES ('9', '1', '12', '我喜欢这个', '0', '1395026221');
INSERT INTO `easy_comment` VALUES ('10', '1', '12', '特别喜欢这篇文章', '0', '1395026258');
INSERT INTO `easy_comment` VALUES ('11', '1', '29', '第一次看到辽阔的大海 内心是非常的欢乐高兴', '0', '1395026308');
INSERT INTO `easy_comment` VALUES ('12', '1', '29', '爱大海', '0', '1395026315');
INSERT INTO `easy_comment` VALUES ('13', '1', '29', '特别喜欢大海', '0', '1395026913');
INSERT INTO `easy_comment` VALUES ('14', '1', '29', '大海的感觉就是干净', '0', '1395026949');
INSERT INTO `easy_comment` VALUES ('15', '1', '31', '特别喜欢', '0', '1395034556');
INSERT INTO `easy_comment` VALUES ('16', '4', '17', '我是asdf发表的评论', '1', '1395057066');
INSERT INTO `easy_comment` VALUES ('17', '12', '16', '我喜欢你', '0', '1395057095');
INSERT INTO `easy_comment` VALUES ('18', '4', '17', '我是asdf发表的评论', '0', '1395057107');
INSERT INTO `easy_comment` VALUES ('19', '12', '16', '你好啊 啊啊', '0', '1395057125');
INSERT INTO `easy_comment` VALUES ('20', '13', '29', '这是一个号好文章', '0', '1395057128');
INSERT INTO `easy_comment` VALUES ('21', '14', '29', 'easycms正式上线', '0', '1395057217');
INSERT INTO `easy_comment` VALUES ('22', '12', '17', '好开心啊', '0', '1395057222');
INSERT INTO `easy_comment` VALUES ('23', '12', '11', '好开心啊啊啊啊啊', '0', '1395057236');
INSERT INTO `easy_comment` VALUES ('24', '15', '11', '真他妈的长', '0', '1395057304');
INSERT INTO `easy_comment` VALUES ('30', '20', '31', '方巾阔服', '0', '1395060071');
INSERT INTO `easy_comment` VALUES ('31', '1', '35', '我操你没', '0', '1395062109');

-- -----------------------------
-- Table structure for `easy_fields`
-- -----------------------------
DROP TABLE IF EXISTS `easy_fields`;
CREATE TABLE `easy_fields` (
  `fields_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `field` varchar(30) NOT NULL,
  `content` text NOT NULL,
  `issystem` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`fields_id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `easy_fields`
-- -----------------------------
INSERT INTO `easy_fields` VALUES ('1', 'title', 'EasyCMS测试站', '1');
INSERT INTO `easy_fields` VALUES ('2', 'description', 'EasyCMS是轻量级可扩展的开源内容管理程序，遵循Apache2开源协议发布', '1');
INSERT INTO `easy_fields` VALUES ('3', 'copyright', '© 2014EasyCMS  版权所有 ', '1');
INSERT INTO `easy_fields` VALUES ('4', 'announcement', 'EasyCMS是轻量级可扩展的开源内容管理程序，<span style=\"color: rgb(34, 34, 34); font-family: Consolas, \'Lucida Console\', monospace; white-space: pre-wrap;\"><strong>遵循Apache2开源协议发布</strong></span><br />本站是EasyCMS的测试站<br />EasyCMS源码下载地址：<a href=\"http://d.easycms.cc/\">http://d.easycms.cc/</a><br /><p><span style=\"color:#999999;\">开发人员：&nbsp;</span></p><p><span style=\"color:#999999;\">陈捷c@easycms.cc</span></p><p><span style=\"color:#999999;\">石武浩s@easycms.cc</span></p><p><span style=\"color:#999999;\">柳杰彬l@easycms.cc</span></p>', '1');
INSERT INTO `easy_fields` VALUES ('5', 'ad', '', '1');

-- -----------------------------
-- Table structure for `easy_link`
-- -----------------------------
DROP TABLE IF EXISTS `easy_link`;
CREATE TABLE `easy_link` (
  `link_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `isverify` tinyint(1) unsigned NOT NULL,
  PRIMARY KEY (`link_id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `easy_member_user`
-- -----------------------------
DROP TABLE IF EXISTS `easy_member_user`;
CREATE TABLE `easy_member_user` (
  `user_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(15) NOT NULL,
  `password` char(32) NOT NULL,
  `email` varchar(32) NOT NULL,
  `sex` tinyint(1) unsigned NOT NULL,
  `photo` char(100) NOT NULL,
  `regtime` int(10) unsigned NOT NULL DEFAULT '0',
  `regip` char(15) NOT NULL,
  `islock` tinyint(1) unsigned NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=29 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `easy_member_user`
-- -----------------------------
INSERT INTO `easy_member_user` VALUES ('1', 'chenjie', '86c09978e5d437ea471363219a52cfde', 'chenjiesuper@163.com', '1', '1395054738_3708650.jpg', '1394962254', '127.0.0.1', '1');
INSERT INTO `easy_member_user` VALUES ('2', '海浪', '86c09978e5d437ea471363219a52cfde', 'chenjiesuper@163.com', '1', '', '1395056767', '192.168.191.2', '0');
INSERT INTO `easy_member_user` VALUES ('3', '柳杰斌', 'ecb97ffafc1798cd2f67fcbc37226761', 'zxc@qq.com', '1', '1395056798_5209489.jpeg', '1395056770', '192.168.191.1', '0');
INSERT INTO `easy_member_user` VALUES ('4', 'asdf', 'c44a471bd78cc6c2fea32b9fe028d30a', 'asdf@qq.com', '1', '1395056935_8331581.jpg', '1395056795', '192.168.191.3', '0');
INSERT INTO `easy_member_user` VALUES ('5', '水熊', '86c09978e5d437ea471363219a52cfde', 'chenjiesuper@126.com', '1', '', '1395056809', '192.168.191.2', '0');
INSERT INTO `easy_member_user` VALUES ('6', '枯叶', 'ecb97ffafc1798cd2f67fcbc37226761', 'zxc@qq.com', '1', '1395056855_5534524.jpg', '1395056840', '192.168.191.1', '0');
INSERT INTO `easy_member_user` VALUES ('7', 'hello', '86c09978e5d437ea471363219a52cfde', 'chenjiesuper@gmail.com', '1', '', '1395056845', '192.168.191.2', '0');
INSERT INTO `easy_member_user` VALUES ('8', '爱美女', '86c09978e5d437ea471363219a52cfde', 'c@chenjie.info', '1', '1395056902_8751554.jpg', '1395056890', '192.168.191.2', '0');
INSERT INTO `easy_member_user` VALUES ('9', 'kaka', 'ecb97ffafc1798cd2f67fcbc37226761', '215483018@qq.com', '1', '1395056954_2445532.jpg', '1395056932', '192.168.191.1', '0');
INSERT INTO `easy_member_user` VALUES ('10', '活雷锋', '86c09978e5d437ea471363219a52cfde', 'chenjiesuper@126.com', '1', '1395056950_8144819.jpg', '1395056939', '192.168.191.2', '0');
INSERT INTO `easy_member_user` VALUES ('11', 'kaixin', '86c09978e5d437ea471363219a52cfde', 'chenjiesuper@163.com', '1', '1395056999_1254422.jpg', '1395056991', '192.168.191.2', '0');
INSERT INTO `easy_member_user` VALUES ('12', '喜欢你', '86c09978e5d437ea471363219a52cfde', 'chenjiesuper@163.com', '1', '', '1395057068', '192.168.191.2', '0');
INSERT INTO `easy_member_user` VALUES ('13', 'deadleaves', 'ecb97ffafc1798cd2f67fcbc37226761', '215483018@qq.com', '1', '1395057087_7248337.jpeg', '1395057074', '192.168.191.1', '0');
INSERT INTO `easy_member_user` VALUES ('14', '石武浩', 'c44a471bd78cc6c2fea32b9fe028d30a', 'asdf@qq.com', '1', '', '1395057168', '192.168.191.3', '0');
INSERT INTO `easy_member_user` VALUES ('15', '明天会更好', 'a8f5f167f44f4964e6c998dee827110c', '215483018@qq.com', '1', '1395057225_2360808.jpg', '1395057199', '192.168.191.1', '0');
INSERT INTO `easy_member_user` VALUES ('17', '柳杰彬', 'ecb97ffafc1798cd2f67fcbc37226761', '215483018@qq.com', '1', '1395057673_5745327.JPG', '1395057618', '192.168.191.1', '0');
INSERT INTO `easy_member_user` VALUES ('18', 'xx', 'c44a471bd78cc6c2fea32b9fe028d30a', 'xx@qq.com', '1', '1395057675_2935838.jpg', '1395057657', '192.168.191.3', '0');
INSERT INTO `easy_member_user` VALUES ('19', '妈妈说我很乖', 'ecb97ffafc1798cd2f67fcbc37226761', 'zxc@qq.com', '1', '1395057944_1834329.jpg', '1395057925', '192.168.191.1', '0');
INSERT INTO `easy_member_user` VALUES ('20', 'dead', 'ecb97ffafc1798cd2f67fcbc37226761', '215483018@qq.com', '1', '1395059700_2302750.JPG', '1395059351', '192.168.191.1', '1');
INSERT INTO `easy_member_user` VALUES ('21', '啊啊啊啊啊', 'e09c80c42fda55f9d992e59ca6b3307d', '916402586@qq.com', '1', '', '1395153974', '120.192.231.89', '0');
INSERT INTO `easy_member_user` VALUES ('22', '601301724@qq.co', '25f9e794323b453885f5181f1b624d0b', '601301724@qq.com', '1', '1395381637_2639038.png', '1395381599', '123.161.203.252', '0');
INSERT INTO `easy_member_user` VALUES ('23', 'zhangjmy', 'e10adc3949ba59abbe56e057f20f883e', 'zhangjmy@163.com', '1', '', '1395386778', '14.18.54.240', '0');
INSERT INTO `easy_member_user` VALUES ('24', 'eysajan', '877024855c92288d16c1df4bd1b647c6', '409766792@qq.com', '1', '', '1395408984', '49.113.234.226', '0');
INSERT INTO `easy_member_user` VALUES ('25', 'a123456', 'edeb1e9ed54c7692c9c4ba413848efc9', 'sadasa@qq.com', '1', '1395476310_7538268.jpg', '1395476257', '27.14.188.67', '0');
INSERT INTO `easy_member_user` VALUES ('26', 'mike33', '88e665b0518ec8418af4d49a2dad9694', '10579272@qq.com', '1', '', '1395495311', '122.241.143.64', '0');
INSERT INTO `easy_member_user` VALUES ('27', 'liphidge', '41506481820b3265f5053e8c9dd614c1', 'long8782@126.com', '1', '', '1395497554', '119.181.154.249', '0');
INSERT INTO `easy_member_user` VALUES ('28', 'eric', 'e10adc3949ba59abbe56e057f20f883e', '2448290642@qq.com', '1', '', '1395501532', '110.210.30.106', '0');

-- -----------------------------
-- Table structure for `easy_node`
-- -----------------------------
DROP TABLE IF EXISTS `easy_node`;
CREATE TABLE `easy_node` (
  `id` smallint(6) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `title` varchar(50) DEFAULT NULL,
  `status` tinyint(1) DEFAULT '0',
  `remark` varchar(255) DEFAULT NULL,
  `sort` smallint(6) unsigned DEFAULT NULL,
  `pid` smallint(6) unsigned NOT NULL,
  `level` tinyint(1) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `level` (`level`),
  KEY `pid` (`pid`),
  KEY `status` (`status`),
  KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=64 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `easy_node`
-- -----------------------------
INSERT INTO `easy_node` VALUES ('1', 'Admin', '后台应用', '1', '后台应用', '0', '0', '1');
INSERT INTO `easy_node` VALUES ('2', 'Rbacuser', 'RBAC用户管理', '1', 'RBAC用户管理', '0', '1', '2');
INSERT INTO `easy_node` VALUES ('3', 'Rbacrole', 'RBAC角色管理', '1', 'RBAC角色管理', '0', '1', '2');
INSERT INTO `easy_node` VALUES ('4', 'Rbacnode', 'RBAC节点管理', '1', 'RBAC节点管理', '0', '1', '2');
INSERT INTO `easy_node` VALUES ('5', 'Rbacaccess', 'RBAC权限分配', '1', 'RBAC权限分配', '0', '1', '2');
INSERT INTO `easy_node` VALUES ('62', 'Database', '数据库管理', '1', '数据库管理', '0', '1', '2');
INSERT INTO `easy_node` VALUES ('7', 'Link', '友情连接管理', '1', '友情连接管理', '0', '1', '2');
INSERT INTO `easy_node` VALUES ('8', 'Plugin', '插件管理', '1', '插件管理', '0', '1', '2');
INSERT INTO `easy_node` VALUES ('9', 'Comment', '文章评论管理', '1', '文章评论管理', '0', '1', '2');
INSERT INTO `easy_node` VALUES ('10', 'Articlem', '文章内容管理', '1', '文章内容管理', '0', '1', '2');
INSERT INTO `easy_node` VALUES ('11', 'Category', '文章分类管理', '1', '文章分类管理', '0', '1', '2');
INSERT INTO `easy_node` VALUES ('12', 'add', '添加用户', '1', '添加用户', '0', '2', '3');
INSERT INTO `easy_node` VALUES ('13', 'edit', '修改用户', '1', '修改用户', '0', '2', '3');
INSERT INTO `easy_node` VALUES ('14', 'delete', '删除用户', '1', '删除用户', '0', '2', '3');
INSERT INTO `easy_node` VALUES ('15', 'index', '浏览系统用户', '1', '浏览系统用户', '0', '2', '3');
INSERT INTO `easy_node` VALUES ('16', 'edit', '修改角色', '1', '修改角色', '0', '3', '3');
INSERT INTO `easy_node` VALUES ('17', 'delete', '删除角色', '1', '删除角色', '0', '3', '3');
INSERT INTO `easy_node` VALUES ('18', 'add', '添加角色', '1', '添加角色', '0', '3', '3');
INSERT INTO `easy_node` VALUES ('19', 'index', '浏览角色', '1', '浏览角色', '0', '3', '3');
INSERT INTO `easy_node` VALUES ('20', 'editpwd', '修改密码', '1', '修改密码', '0', '4', '3');
INSERT INTO `easy_node` VALUES ('21', 'edit', '修改用户', '1', '修改用户', '0', '4', '3');
INSERT INTO `easy_node` VALUES ('22', 'delete', '删除用户', '1', '删除用户', '0', '4', '3');
INSERT INTO `easy_node` VALUES ('23', 'add', '添加用户', '1', '添加用户', '0', '4', '3');
INSERT INTO `easy_node` VALUES ('24', 'index', '浏览节点', '1', '浏览节点', '0', '4', '3');
INSERT INTO `easy_node` VALUES ('25', 'edit', '权限浏览', '1', '权限浏览', '0', '5', '3');
INSERT INTO `easy_node` VALUES ('56', 'User', '会员管理', '1', '会员管理', '0', '1', '2');
INSERT INTO `easy_node` VALUES ('63', 'index', '数据还原', '1', '数据还原', '0', '62', '3');
INSERT INTO `easy_node` VALUES ('29', 'add', '添加连接', '1', '添加连接', '0', '7', '3');
INSERT INTO `easy_node` VALUES ('30', 'edit', '修改连接', '1', '修改连接', '0', '7', '3');
INSERT INTO `easy_node` VALUES ('31', 'delete', '删除连接', '1', '删除连接', '0', '7', '3');
INSERT INTO `easy_node` VALUES ('32', 'index', '浏览友情连接', '1', '浏览友情连接', '0', '7', '3');
INSERT INTO `easy_node` VALUES ('33', 'changeInstall', '安装卸载', '1', '安装卸载', '0', '8', '3');
INSERT INTO `easy_node` VALUES ('34', 'edit', '插件配置', '1', '插件配置', '0', '8', '3');
INSERT INTO `easy_node` VALUES ('35', 'index', '插件浏览', '1', '插件浏览', '0', '8', '3');
INSERT INTO `easy_node` VALUES ('36', 'changeState', '回收评论', '1', '回收评论', '0', '9', '3');
INSERT INTO `easy_node` VALUES ('37', 'rubAll', '批量回收', '1', '批量回收', '0', '9', '3');
INSERT INTO `easy_node` VALUES ('38', 'delAll', '批量删除', '1', '批量删除', '0', '9', '3');
INSERT INTO `easy_node` VALUES ('39', 'index', '浏览评论', '1', '浏览评论', '0', '9', '3');
INSERT INTO `easy_node` VALUES ('40', 'add', '添加文章', '1', '添加文章', '0', '10', '3');
INSERT INTO `easy_node` VALUES ('41', 'edit', '修改文章', '1', '修改文章', '0', '10', '3');
INSERT INTO `easy_node` VALUES ('42', 'changeState', '回收文章', '1', '回收文章', '0', '10', '3');
INSERT INTO `easy_node` VALUES ('43', 'rubAll', '批量回收', '1', '批量回收', '0', '10', '3');
INSERT INTO `easy_node` VALUES ('44', 'recAll', '批量恢复', '1', '批量恢复', '0', '10', '3');
INSERT INTO `easy_node` VALUES ('45', 'delAll', '永久删除', '1', '永久删除', '0', '10', '3');
INSERT INTO `easy_node` VALUES ('46', 'index', '浏览文章', '1', '浏览文章', '0', '10', '3');
INSERT INTO `easy_node` VALUES ('47', 'index', '浏览分类', '1', '浏览分类', '0', '11', '3');
INSERT INTO `easy_node` VALUES ('48', 'add', '添加分类', '1', '添加分类', '0', '11', '3');
INSERT INTO `easy_node` VALUES ('49', 'edit', '修改分类', '1', '修改分类', '0', '11', '3');
INSERT INTO `easy_node` VALUES ('50', 'delete', '删除分类', '1', '删除分类', '0', '11', '3');
INSERT INTO `easy_node` VALUES ('51', 'changeState', '状态操作', '1', '状态操作', '0', '11', '3');
INSERT INTO `easy_node` VALUES ('52', 'Index', '前端应用', '1', '前端应用', '0', '0', '1');
INSERT INTO `easy_node` VALUES ('53', 'rubbish', '文章回收站', '1', '文章回收站', '0', '10', '3');
INSERT INTO `easy_node` VALUES ('54', 'rubbish', '评论回收站', '1', '评论回收站', '0', '9', '3');
INSERT INTO `easy_node` VALUES ('55', 'recAll', '批量恢复', '1', '批量恢复', '0', '9', '3');
INSERT INTO `easy_node` VALUES ('57', 'index', '浏览会员', '1', '浏览会员', '0', '56', '3');
INSERT INTO `easy_node` VALUES ('58', 'add', '添加会员', '1', '添加会员', '0', '56', '3');
INSERT INTO `easy_node` VALUES ('59', 'delete', '删除会员', '1', '删除会员', '0', '56', '3');
INSERT INTO `easy_node` VALUES ('60', 'delAll', '批量删除', '1', '批量删除', '0', '56', '3');
INSERT INTO `easy_node` VALUES ('61', 'editpwd', '修改密码', '1', '修改密码', '0', '56', '3');

-- -----------------------------
-- Table structure for `easy_plugin`
-- -----------------------------
DROP TABLE IF EXISTS `easy_plugin`;
CREATE TABLE `easy_plugin` (
  `plugin_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(32) NOT NULL,
  `desc` varchar(255) NOT NULL DEFAULT '无',
  `method` varchar(255) NOT NULL,
  `isinstalled` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `position` tinyint(4) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`plugin_id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `easy_plugin`
-- -----------------------------
INSERT INTO `easy_plugin` VALUES ('7', 'Baidushare', '百度分享', 'Index/Baidushare/info', '1', '1');

-- -----------------------------
-- Table structure for `easy_role`
-- -----------------------------
DROP TABLE IF EXISTS `easy_role`;
CREATE TABLE `easy_role` (
  `id` smallint(6) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `pid` smallint(6) DEFAULT NULL,
  `status` tinyint(1) unsigned DEFAULT NULL,
  `remark` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `pid` (`pid`),
  KEY `status` (`status`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `easy_role`
-- -----------------------------
INSERT INTO `easy_role` VALUES ('7', '测试帐号', '0', '1', '测试帐号');

-- -----------------------------
-- Table structure for `easy_role_user`
-- -----------------------------
DROP TABLE IF EXISTS `easy_role_user`;
CREATE TABLE `easy_role_user` (
  `role_id` mediumint(9) unsigned DEFAULT NULL,
  `user_id` char(32) DEFAULT NULL,
  KEY `group_id` (`role_id`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `easy_role_user`
-- -----------------------------
INSERT INTO `easy_role_user` VALUES ('3', '7');
INSERT INTO `easy_role_user` VALUES ('4', '8');
INSERT INTO `easy_role_user` VALUES ('3', '9');
INSERT INTO `easy_role_user` VALUES ('5', '10');
INSERT INTO `easy_role_user` VALUES ('5', '11');
INSERT INTO `easy_role_user` VALUES ('6', '12');
INSERT INTO `easy_role_user` VALUES ('7', '13');

-- -----------------------------
-- Table structure for `easy_user`
-- -----------------------------
DROP TABLE IF EXISTS `easy_user`;
CREATE TABLE `easy_user` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `username` char(20) NOT NULL DEFAULT '',
  `password` char(32) NOT NULL DEFAULT '',
  `logintime` int(10) unsigned NOT NULL,
  `loginip` varchar(30) NOT NULL,
  `lock` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `easy_user`
-- -----------------------------
INSERT INTO `easy_user` VALUES ('6', 'admin', '21232f297a57a5a743894a0e4a801fc3', '1449859892', '0.0.0.0', '0');
INSERT INTO `easy_user` VALUES ('13', 'demo', 'fe01ce2a7fbac8fafaed7c982a04e229', '1396106659', '127.0.0.1', '0');
